# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['plcpidgeon']

package_data = \
{'': ['*']}

install_requires = \
['pylogix>=0.8.6,<0.9.0', 'scapy>=2.4.5,<3.0.0', 'typer[all]>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['fly = plcpidgeon.logdata.log_task',
                     'pidgeon = plcpidgeon.plcpidgeon:app']}

setup_kwargs = {
    'name': 'plcpidgeon',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Ryan Wilson',
    'author_email': 'rwilson@greenerd.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
